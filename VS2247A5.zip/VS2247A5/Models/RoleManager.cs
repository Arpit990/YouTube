﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using VS2247A5.Models;

namespace VS2247A5.Controllers
{
    public class RoleManager
    {
        private readonly ApplicationDbContext ds = new ApplicationDbContext();

        public bool LoadRoles()
        {
            var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(ds));

            if (!roleManager.RoleExists("Administrator"))
                roleManager.Create(new IdentityRole { Name = "Administrator" });
            if (!roleManager.RoleExists("Executive"))
                roleManager.Create(new IdentityRole { Name = "Executive" });
            if (!roleManager.RoleExists("Coordinator"))
                roleManager.Create(new IdentityRole { Name = "Coordinator" });
            if (!roleManager.RoleExists("Clerk"))
                roleManager.Create(new IdentityRole { Name = "Clerk" });

            return true;
        }
    }
}