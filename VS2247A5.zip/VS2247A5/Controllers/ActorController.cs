﻿using System.Net;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using VS2247A5.ViewModels;

namespace VS2247A5.Controllers
{
    public class ActorController : Controller
    {
        private readonly Manager m = new Manager();

        // GET: Actor
        public ActionResult Index()
        {
            return View(m.GetAllActors());
        }

        // GET: Actor/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var actor = m.GetActorById(id.Value);
            if (actor == null)
                return HttpNotFound();

            return View(actor);
        }

        // GET: Actor/Create
        [Authorize(Roles = "Executive")]
        public ActionResult Create()
        {
            return View(new ActorAddViewModel());
        }

        // POST: Actor/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Executive")]
        public ActionResult Create(ActorAddViewModel actor)
        {
            if (!ModelState.IsValid)
                return View(actor);

            try
            {
                var actorId = m.AddActor(actor, User.Identity.Name);
                return RedirectToAction("Details", new { id = actorId });
            }
            catch
            {
                return View(actor);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                m.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}