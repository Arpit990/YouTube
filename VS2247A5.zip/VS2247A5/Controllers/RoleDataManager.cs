﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using VS2247A5.Models;

namespace VS2247A5.Controllers
{
    public class RoleDataManager
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        public bool LoadRoles()
        {
            var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(db));

            var roles = new[] { "Administrator", "Executive", "Coordinator", "Clerk" };
            var result = true;

            foreach (var roleName in roles)
            {
                if (!roleManager.RoleExists(roleName))
                {
                    result = roleManager.Create(new IdentityRole(roleName)).Succeeded && result;
                }
            }

            return result;
        }
    }
}