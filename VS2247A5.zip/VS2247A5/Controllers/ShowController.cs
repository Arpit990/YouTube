﻿using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using System.Net;
using VS2247A5.ViewModels;
using System.Linq;
using System;

namespace VS2247A5.Controllers
{
    public class ShowController : Controller
    {
        private readonly Manager m = new Manager();

        // GET: Show
        public ActionResult Index()
        {
            return View(m.GetAllShows());
        }

        // GET: Show/Create
        [Authorize(Roles = "Coordinator")]
        public ActionResult Create()
        {
            var genres = m.GetAllGenres().ToList();  // Get all genres
            if (!genres.Any())
            {
                TempData["Error"] = "No genres available. Please ask administrator to load genres first.";
                return RedirectToAction("Index");
            }

            var actors = m.GetAllActors().ToList();  // Get all actors
            if (!actors.Any())
            {
                TempData["Error"] = "No actors available. Please add actors before creating a show.";
                return RedirectToAction("Index");
            }

            var form = new ShowAddViewModel
            {
                ReleaseDate = DateTime.Now,  // Set default date
                GenreList = new SelectList(genres, "Name", "Name", genres.FirstOrDefault()?.Name),
                ActorList = new MultiSelectList(actors, "Id", "Name")
            };
            return View(form);
        }


        // POST: Show/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Coordinator")]
        public ActionResult Create(ShowAddViewModel show)
        {
            if (!ModelState.IsValid)
            {
                var genres = m.GetAllGenres().ToList();
                var actors = m.GetAllActors().ToList();

                show.GenreList = new SelectList(genres, "Name", "Name", show.Genre);
                show.ActorList = new MultiSelectList(actors, "Id", "Name", show.ActorIds);
                return View(show);
            }

            try
            {
                // Ensure at least one actor is selected
                if (show.ActorIds == null || !show.ActorIds.Any())
                {
                    ModelState.AddModelError("ActorIds", "Please select at least one actor.");
                    var genres = m.GetAllGenres().ToList();
                    var actors = m.GetAllActors().ToList();
                    show.GenreList = new SelectList(genres, "Name", "Name", show.Genre);
                    show.ActorList = new MultiSelectList(actors, "Id", "Name", show.ActorIds);
                    return View(show);
                }

                var showId = m.AddShow(show, User.Identity.Name);
                return RedirectToAction("Details", new { id = showId });
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "Error creating show: " + ex.Message);
                var genres = m.GetAllGenres().ToList();
                var actors = m.GetAllActors().ToList();
                show.GenreList = new SelectList(genres, "Name", "Name", show.Genre);
                show.ActorList = new MultiSelectList(actors, "Id", "Name", show.ActorIds);
                return View(show);
            }
        }


        // GET: Show/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var show = m.GetShowById(id.Value);
            if (show == null)
                return HttpNotFound();

            return View(show);
        }

        // GET: Show/{id}/AddEpisode
        [Authorize(Roles = "Clerk")]
        [Route("Show/{id}/AddEpisode")]
        public ActionResult AddEpisode(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var show = m.GetShowById(id.Value);
            if (show == null)
                return HttpNotFound();

            var form = new EpisodeAddViewModel
            {
                ShowId = id.Value,
                ShowName = show.Name,
                GenreList = new SelectList(m.GetAllGenres(), "Name", "Name")
            };

            return View(form);
        }

        // POST: Show/{id}/AddEpisode
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Clerk")]
        [Route("Show/{id}/AddEpisode")]
        public ActionResult AddEpisode(int? id, EpisodeAddViewModel episode)
        {
            if (!ModelState.IsValid)
            {
                var show = m.GetShowById(id.Value);
                episode.ShowName = show.Name;
                episode.GenreList = new SelectList(m.GetAllGenres(), "Name", "Name");
                return View(episode);
            }

            try
            {
                var episodeId = m.AddEpisode(episode, User.Identity.Name);
                return RedirectToAction("Details", "Episode", new { id = episodeId });
            }
            catch
            {
                var show = m.GetShowById(id.Value);
                episode.ShowName = show.Name;
                episode.GenreList = new SelectList(m.GetAllGenres(), "Name", "Name");
                return View(episode);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                m.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}