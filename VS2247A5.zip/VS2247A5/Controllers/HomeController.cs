﻿using System;
using System.Web.Mvc;
using System.Configuration;

namespace VS2247A5.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.DeployedURL = "https://vsharma176-wa-web524-a5.azurewebsites.net";
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your TV Show Management application.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }
    }
}