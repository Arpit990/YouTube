﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using AutoMapper;
using VS2247A5.Data;
using VS2247A5.Models;
using VS2247A5.ViewModels;

namespace VS2247A5.Controllers
{
    public class Manager : IDisposable
    {
        private readonly ApplicationDbContext ds = new ApplicationDbContext();
        private static bool isMapperInitialized = false;

        public Manager()
        {
            if (!isMapperInitialized)
            {
                Mapper.Initialize(cfg =>
                {
                    // Genre mappings
                    cfg.CreateMap<Genre, GenreBaseViewModel>();

                    // Actor mappings
                    cfg.CreateMap<Actor, ActorBaseViewModel>();
                    cfg.CreateMap<Actor, ActorWithShowInfoViewModel>()
                        .ForMember(dest => dest.Shows, opt => opt.MapFrom(src => src.Shows));
                    cfg.CreateMap<ActorAddViewModel, Actor>();

                    // Show mappings
                    cfg.CreateMap<Show, ShowBaseViewModel>();
                    cfg.CreateMap<Show, ShowWithInfoViewModel>()
                        .ForMember(dest => dest.Actors, opt => opt.MapFrom(src => src.Actors))
                        .ForMember(dest => dest.Episodes, opt => opt.MapFrom(src => src.Episodes));
                    cfg.CreateMap<ShowAddViewModel, Show>();

                    // Episode mappings
                    cfg.CreateMap<Episode, EpisodeBaseViewModel>();
                    cfg.CreateMap<Episode, EpisodeWithShowNameViewModel>()
                        .ForMember(dest => dest.ShowName, opt => opt.MapFrom(src => src.Show.Name));
                    cfg.CreateMap<EpisodeAddViewModel, Episode>();
                });
                isMapperInitialized = true;
            }
        }

        // Load initial data methods
        public bool LoadGenres()
        {
            if (ds.Genres.Any())
                return false;

            var genres = new List<Genre>
    {
        new Genre { Name = "Action" },
        new Genre { Name = "Comedy" },
        new Genre { Name = "Drama" },
        new Genre { Name = "Horror" },
        new Genre { Name = "Romance" },
        new Genre { Name = "Sci-Fi" },
        new Genre { Name = "Thriller" },
        new Genre { Name = "Documentary" },
        new Genre { Name = "Animation" },
        new Genre { Name = "Mystery" }
    };

            ds.Genres.AddRange(genres);
            ds.SaveChanges();
            return true;
        }

        public bool LoadActors(string executiveUserName)
        {
            if (ds.Actors.Any()) return false;

            var actors = new List<Actor>
            {
                new Actor
                {
                    Name = "Morgan Freeman",
                    BirthDate = new DateTime(1937, 6, 1),
                    Height = 1.88,
                    ImageUrl = "https://example.com/morgan-freeman.jpg",
                    Executive = executiveUserName
                },
                new Actor
                {
                    Name = "Meryl Streep",
                    BirthDate = new DateTime(1949, 6, 22),
                    Height = 1.68,
                    ImageUrl = "https://example.com/meryl-streep.jpg",
                    Executive = executiveUserName
                },
                new Actor
                {
                    Name = "Tom Hanks",
                    BirthDate = new DateTime(1956, 7, 9),
                    Height = 1.83,
                    ImageUrl = "https://example.com/tom-hanks.jpg",
                    Executive = executiveUserName
                }
            };

            ds.Actors.AddRange(actors);
            ds.SaveChanges();
            return true;
        }

        // Continue with Manager class methods...
        public bool LoadShows(string coordinatorUserName)
        {
            if (ds.Shows.Any()) return false;

            var actors = ds.Actors.ToList();
            if (!actors.Any()) return false;

            var shows = new List<Show>
            {
                new Show
                {
                    Name = "The Crown",
                    Genre = "Drama",
                    ReleaseDate = DateTime.Now.AddMonths(-6),
                    ImageUrl = "https://example.com/the-crown.jpg",
                    Coordinator = coordinatorUserName,
                    Actors = new List<Actor> { actors[0] }
                },
                new Show
                {
                    Name = "Stranger Things",
                    Genre = "Sci-Fi",
                    ReleaseDate = DateTime.Now.AddMonths(-3),
                    ImageUrl = "https://example.com/stranger-things.jpg",
                    Coordinator = coordinatorUserName,
                    Actors = new List<Actor> { actors[1] }
                }
            };

            ds.Shows.AddRange(shows);
            ds.SaveChanges();
            return true;
        }

        public bool LoadEpisodes(string clerkUserName)
        {
            if (ds.Episodes.Any()) return false;

            var shows = ds.Shows.ToList();
            if (!shows.Any()) return false;

            foreach (var show in shows)
            {
                for (int i = 1; i <= 3; i++)
                {
                    ds.Episodes.Add(new Episode
                    {
                        Name = $"{show.Name} - Episode {i}",
                        SeasonNumber = 1,
                        EpisodeNumber = i,
                        Genre = show.Genre,
                        AirDate = DateTime.Now.AddDays(i * 7),
                        ImageUrl = $"https://example.com/{show.Name.ToLower().Replace(" ", "-")}-s01e{i}.jpg",
                        Clerk = clerkUserName,
                        Show = show
                    });
                }
            }

            ds.SaveChanges();
            return true;
        }

        // Genre methods
        public IEnumerable<GenreBaseViewModel> GetAllGenres()
        {
            // If no genres exist, load the default ones
            if (!ds.Genres.Any())
            {
                LoadGenres();
            }

            return Mapper.Map<IEnumerable<Genre>, IEnumerable<GenreBaseViewModel>>(
                ds.Genres.OrderBy(g => g.Name));
        }

        // Actor methods
        public IEnumerable<ActorBaseViewModel> GetAllActors()
        {
            return Mapper.Map<IEnumerable<Actor>, IEnumerable<ActorBaseViewModel>>(
                ds.Actors.OrderBy(a => a.Name));
        }

        public ActorWithShowInfoViewModel GetActorById(int id)
        {
            var actor = ds.Actors.Include(a => a.Shows)
                .SingleOrDefault(a => a.Id == id);
            return actor == null ? null : Mapper.Map<Actor, ActorWithShowInfoViewModel>(actor);
        }

        public int AddActor(ActorAddViewModel newActor, string executiveUserName)
        {
            var actor = Mapper.Map<ActorAddViewModel, Actor>(newActor);
            actor.Executive = executiveUserName;
            ds.Actors.Add(actor);
            ds.SaveChanges();
            return actor.Id;
        }

        // Show methods
        public IEnumerable<ShowBaseViewModel> GetAllShows()
        {
            return Mapper.Map<IEnumerable<Show>, IEnumerable<ShowBaseViewModel>>(
                ds.Shows.OrderBy(s => s.Name));
        }

        public ShowWithInfoViewModel GetShowById(int id)
        {
            var show = ds.Shows.Include(s => s.Actors)
                              .Include(s => s.Episodes)
                              .SingleOrDefault(s => s.Id == id);
            return show == null ? null : Mapper.Map<Show, ShowWithInfoViewModel>(show);
        }

        public int AddShow(ShowAddViewModel newShow, string coordinatorUserName)
        {
            var show = Mapper.Map<ShowAddViewModel, Show>(newShow);
            show.Coordinator = coordinatorUserName;

            if (newShow.ActorIds != null && newShow.ActorIds.Any())
            {
                show.Actors = ds.Actors.Where(a => newShow.ActorIds.Contains(a.Id)).ToList();
            }

            ds.Shows.Add(show);
            ds.SaveChanges();
            return show.Id;
        }

        // Episode methods
        public IEnumerable<EpisodeWithShowNameViewModel> GetAllEpisodes()
        {
            return Mapper.Map<IEnumerable<Episode>, IEnumerable<EpisodeWithShowNameViewModel>>(
                ds.Episodes.Include(e => e.Show)
                    .OrderBy(e => e.Show.Name)
                    .ThenBy(e => e.SeasonNumber)
                    .ThenBy(e => e.EpisodeNumber));
        }

        public EpisodeWithShowNameViewModel GetEpisodeById(int id)
        {
            var episode = ds.Episodes.Include(e => e.Show)
                .SingleOrDefault(e => e.Id == id);
            return episode == null ? null : Mapper.Map<Episode, EpisodeWithShowNameViewModel>(episode);
        }

        public int AddEpisode(EpisodeAddViewModel newEpisode, string clerkUserName)
        {
            var episode = Mapper.Map<EpisodeAddViewModel, Episode>(newEpisode);
            episode.Clerk = clerkUserName;

            var show = ds.Shows.Find(newEpisode.ShowId);
            if (show == null)
                throw new InvalidOperationException("Show not found");

            episode.Show = show;
            ds.Episodes.Add(episode);
            ds.SaveChanges();
            return episode.Id;
        }

        // Database management methods
        public bool RemoveDatabase()
        {
            try
            {
                return ds.Database.Delete();
            }
            catch
            {
                return false;
            }
        }

        public void Dispose()
        {
            ds.Dispose();
        }
    }
}