﻿using System.Web.Mvc;

namespace VS2247A5.Controllers
{
    public class GenreController : Controller
    {
        private readonly Manager m = new Manager();

        // GET: Genre
        public ActionResult Index()
        {
            return View(m.GetAllGenres());
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                m.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}