﻿using System.Web.Mvc;
using Microsoft.AspNet.Identity;

namespace VS2247A5.Controllers
{
    [Authorize(Roles = "Administrator")]
    public class LoadDataController : Controller
    {
        private readonly Manager m = new Manager();

        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }

        [AllowAnonymous]
        public ActionResult Roles()
        {
            var roleManager = new RoleDataManager();
            var result = roleManager.LoadRoles();
            return Content(result ? "Roles were loaded" : "Roles were not loaded");
        }

        public ActionResult Genres()
        {
            var result = m.LoadGenres();
            return Content(result ? "Genres were loaded" : "Genres were not loaded");
        }

        public ActionResult Actors()
        {
            var result = m.LoadActors(User.Identity.Name);
            return Content(result ? "Actors were loaded" : "Actors were not loaded");
        }

        public ActionResult Shows()
        {
            var result = m.LoadShows(User.Identity.Name);
            return Content(result ? "Shows were loaded" : "Shows were not loaded");
        }

        public ActionResult Episodes()
        {
            var result = m.LoadEpisodes(User.Identity.Name);
            return Content(result ? "Episodes were loaded" : "Episodes were not loaded");
        }

        public ActionResult RemoveData()
        {
            var result = m.RemoveDatabase();
            return Content(result ? "Database was removed" : "Database was not removed");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                m.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}