﻿using System;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using VS2247A5.ViewModels;

namespace VS2247A5.Controllers
{
    public class EpisodeController : Controller
    {
        private readonly Manager m = new Manager();

        // GET: Episode
        public ActionResult Index()
        {
            return View(m.GetAllEpisodes());
        }

        // GET: Episode/Create
        [Authorize(Roles = "Clerk")]
        public ActionResult Create()
        {
            var shows = m.GetAllShows().ToList();
            if (!shows.Any())
            {
                TempData["Error"] = "No shows available. Please add shows before creating episodes.";
                return RedirectToAction("Index");
            }

            var form = new EpisodeAddViewModel
            {
                AirDate = DateTime.Now,
                GenreList = new SelectList(m.GetAllGenres(), "Name", "Name"),
                ShowList = new SelectList(shows, "Id", "Name")
            };
            return View(form);
        }

        // POST: Episode/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Clerk")]
        public ActionResult Create(EpisodeAddViewModel episode)
        {
            if (!ModelState.IsValid)
            {
                episode.GenreList = new SelectList(m.GetAllGenres(), "Name", "Name");
                episode.ShowList = new SelectList(m.GetAllShows(), "Id", "Name");
                return View(episode);
            }

            try
            {
                var episodeId = m.AddEpisode(episode, User.Identity.Name);
                return RedirectToAction("Details", new { id = episodeId });
            }
            catch
            {
                episode.GenreList = new SelectList(m.GetAllGenres(), "Name", "Name");
                episode.ShowList = new SelectList(m.GetAllShows(), "Id", "Name");
                return View(episode);
            }
        }

        // GET: Episode/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);

            var episode = m.GetEpisodeById(id.Value);
            if (episode == null)
                return HttpNotFound();

            return View(episode);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                m.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}