﻿namespace VS2247A5.ViewModels
{
    public class BaseViewModel
    {
        public int Id { get; set; }
    }
}