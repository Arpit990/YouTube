﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace VS2247A5.ViewModels
{
    public class EpisodeBaseViewModel : BaseViewModel
    {
        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        [Display(Name = "Season")]
        public int SeasonNumber { get; set; }

        [Display(Name = "Episode")]
        public int EpisodeNumber { get; set; }

        [Required]
        public string Genre { get; set; }

        [Required]
        [Display(Name = "Air Date")]
        [DataType(DataType.Date)]
        public DateTime AirDate { get; set; }

        [Required]
        [Display(Name = "Image URL")]
        [StringLength(250)]
        public string ImageUrl { get; set; }

        public string Clerk { get; set; }

        public int ShowId { get; set; }
    }

    public class EpisodeAddViewModel
    {
        public EpisodeAddViewModel()
        {
            AirDate = DateTime.Now;
        }

        [Required(ErrorMessage = "Episode name is required")]
        [StringLength(150)]
        [Display(Name = "Episode Name")]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Show")]
        public int ShowId { get; set; }

        [Required]
        [Display(Name = "Season Number")]
        [Range(1, int.MaxValue, ErrorMessage = "Season number must be greater than 0")]
        public int SeasonNumber { get; set; }

        [Required]
        [Display(Name = "Episode Number")]
        [Range(1, int.MaxValue, ErrorMessage = "Episode number must be greater than 0")]
        public int EpisodeNumber { get; set; }

        [Required(ErrorMessage = "Genre is required")]
        public string Genre { get; set; }

        [Required]
        [Display(Name = "Air Date")]
        [DataType(DataType.Date)]
        public DateTime AirDate { get; set; }

        [Required(ErrorMessage = "Image URL is required")]
        [Display(Name = "Image URL")]
        [StringLength(250)]
        [Url(ErrorMessage = "Please enter a valid URL")]
        public string ImageUrl { get; set; }

        public string ShowName { get; set; }
        public SelectList GenreList { get; set; }
        public SelectList ShowList { get; set; }
    }
    public class EpisodeWithShowNameViewModel : EpisodeBaseViewModel
    {
        public string ShowName { get; set; }
    }
}