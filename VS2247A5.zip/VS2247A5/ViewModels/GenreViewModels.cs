﻿using System.ComponentModel.DataAnnotations;

namespace VS2247A5.ViewModels
{
    public class GenreBaseViewModel : BaseViewModel
    {
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
    }
}