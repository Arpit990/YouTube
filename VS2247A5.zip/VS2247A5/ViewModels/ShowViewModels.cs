﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace VS2247A5.ViewModels
{
    public class ShowBaseViewModel : BaseViewModel
    {
        [Required]
        [StringLength(150)]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string Genre { get; set; }

        [Required]
        [Display(Name = "Release Date")]
        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }

        [Required]
        [Display(Name = "Image URL")]
        [StringLength(250)]
        public string ImageUrl { get; set; }

        public string Coordinator { get; set; }
    }

    public class ShowAddViewModel
    {
        public ShowAddViewModel()
        {
            // Set default values
            ReleaseDate = DateTime.Now;
            ActorIds = new List<int>();
        }

        [Required(ErrorMessage = "Show name is required")]
        [StringLength(150)]
        [Display(Name = "Show Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Genre is required")]
        public string Genre { get; set; }

        [Required]
        [Display(Name = "Release Date")]
        [DataType(DataType.Date)]
        public DateTime ReleaseDate { get; set; }

        [Required(ErrorMessage = "Image URL is required")]
        [Display(Name = "Image URL")]
        [StringLength(250)]
        [Url(ErrorMessage = "Please enter a valid URL")]
        public string ImageUrl { get; set; }

        [Required(ErrorMessage = "Please select at least one actor")]
        [Display(Name = "Select Actors")]
        public List<int> ActorIds { get; set; }

        public SelectList GenreList { get; set; }
        public MultiSelectList ActorList { get; set; }
        public string KnownActorName { get; set; }
    }

    public class ShowWithInfoViewModel : ShowBaseViewModel
    {
        public ShowWithInfoViewModel()
        {
            Actors = new List<ActorBaseViewModel>();
            Episodes = new List<EpisodeBaseViewModel>();
        }

        public IEnumerable<ActorBaseViewModel> Actors { get; set; }
        public IEnumerable<EpisodeBaseViewModel> Episodes { get; set; }
    }
}