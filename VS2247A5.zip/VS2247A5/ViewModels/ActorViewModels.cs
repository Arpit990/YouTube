﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace VS2247A5.ViewModels
{
    public class ActorBaseViewModel : BaseViewModel
    {
        [Required]
        [StringLength(150)]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Display(Name = "Alternate Name")]
        [StringLength(150)]
        public string AlternateName { get; set; }

        [Display(Name = "Birth Date")]
        [DataType(DataType.Date)]
        public DateTime? BirthDate { get; set; }

        [Display(Name = "Height (m)")]
        public double? Height { get; set; }

        [Required]
        [Display(Name = "Image URL")]
        [StringLength(250)]
        public string ImageUrl { get; set; }

        public string Executive { get; set; }
    }

    public class ActorAddViewModel
    {
        [Required]
        [StringLength(150)]
        [Display(Name = "Full Name")]
        public string Name { get; set; }

        [Display(Name = "Alternate Name")]
        [StringLength(150)]
        public string AlternateName { get; set; }

        [Display(Name = "Birth Date")]
        [DataType(DataType.Date)]
        public DateTime? BirthDate { get; set; }

        [Display(Name = "Height (m)")]
        public double? Height { get; set; }

        [Required]
        [Display(Name = "Image URL")]
        [StringLength(250)]
        public string ImageUrl { get; set; }
    }

    public class ActorWithShowInfoViewModel : ActorBaseViewModel
    {
        public ActorWithShowInfoViewModel()
        {
            Shows = new List<ShowBaseViewModel>();
        }

        public IEnumerable<ShowBaseViewModel> Shows { get; set; }
    }
}